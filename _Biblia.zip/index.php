<?php
// Inclui o arquivo de conexão
include 'includes/conexao.php';

// Verifica se uma pesquisa foi enviada
$termo_pesquisa = '';
$resultados = [];
$redirecionar_para_livro = false;
$livro_id_redirecionar = null;
$capitulo_redirecionar = null;

if (isset($_GET['pesquisa']) && !empty($_GET['pesquisa'])) {
    $termo_pesquisa = trim($_GET['pesquisa']);

    // Verifica se o termo de pesquisa está no formato "Nome do Livro + Número do Capítulo"
    if (preg_match('/^([a-zA-ZÀ-ú\s]+)\s+(\d+)$/', $termo_pesquisa, $matches)) {
        $nome_livro = trim($matches[1]); // Nome do livro (ex: "Salmos")
        $capitulo = intval($matches[2]); // Número do capítulo (ex: 13)

        // Busca o ID do livro pelo nome
        $sql_livro = "SELECT id FROM books WHERE name LIKE :nome_livro";
        $stmt_livro = $pdo->prepare($sql_livro);
        $stmt_livro->execute(['nome_livro' => "%$nome_livro%"]);
        $livro_encontrado = $stmt_livro->fetch(PDO::FETCH_ASSOC);

        if ($livro_encontrado) {
            // Se encontrou o livro, redireciona para o capítulo específico
            $redirecionar_para_livro = true;
            $livro_id_redirecionar = $livro_encontrado['id'];
            $capitulo_redirecionar = $capitulo;
        }
    }

    // Se não foi detectado o formato "Nome do Livro + Número do Capítulo", faz a busca normal
    if (!$redirecionar_para_livro) {
        // Verifica se o termo de pesquisa corresponde ao nome de um livro
        $sql_livro = "SELECT id FROM books WHERE name LIKE :termo";
        $stmt_livro = $pdo->prepare($sql_livro);
        $stmt_livro->execute(['termo' => "%$termo_pesquisa%"]);
        $livro_encontrado = $stmt_livro->fetch(PDO::FETCH_ASSOC);

        if ($livro_encontrado) {
            // Se encontrou um livro, redireciona para a página do livro
            $redirecionar_para_livro = true;
            $livro_id_redirecionar = $livro_encontrado['id'];
        } else {
            // Caso contrário, busca por versículos que contenham o termo
            $sql = "SELECT v.*, b.name AS livro_nome 
                    FROM verses v
                    JOIN books b ON v.book = b.id
                    WHERE v.text LIKE :termo
                    ORDER BY b.id, v.chapter, v.verse";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['termo' => "%$termo_pesquisa%"]);
            $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}

// Redireciona para o livro e capítulo específico, se necessário
if ($redirecionar_para_livro) {
    if ($capitulo_redirecionar) {
        // Redireciona para o capítulo específico
        header("Location: capitulo.php?book=$livro_id_redirecionar&capitulo=$capitulo_redirecionar");
    } else {
        // Redireciona para a página do livro
        header("Location: livro.php?id=$livro_id_redirecionar");
    }
    exit();
}

// Verifica se a requisição é para o service worker
if ($_SERVER['REQUEST_URI'] === '/sw.js') {
    header('Service-Worker-Allowed: /');
    header('Content-Type: application/javascript');
    // Você pode ler e exibir o conteúdo do sw.js aqui se necessário
    exit;
}

// Consulta para buscar todos os livros
$sql_livros = "SELECT * FROM books";
$stmt_livros = $pdo->query($sql_livros);
$livros = $stmt_livros->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon">
    
<link rel="manifest" href="manifest.json" />
<meta name="theme-color" content="#4a90e2" />



    

    <title>Bíblia Online</title>
    <style>
        /* Estilos gerais (mantidos iguais) */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://cdn.arquidiocesesorocaba.org.br/wp-content/uploads/2024/08/11005039/artigo-1108-1024x576.png');
            background-size: cover;             /* cobre toda a tela */
            background-position: center;        /* centraliza a imagem */
            background-repeat: no-repeat;       /* não repete */
            background-attachment: fixed;       /* imagem fixa enquanto rola a página */
            color: white;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: black;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        /* Estilo para a imagem ao lado do título */
        h1 img {
            width: 50px;
            height: 40px;
            border-radius: 50%;
        }

        .search-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .search-container input[type="text"] {
            padding: 10px;
            border: 1px solid rgba(0, 0, 0, 0.9);
            border-radius: 16px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            width: 300px;
        }
        .search-container button {
            padding: 10px 15px;
            border: 1px solid rgba(0, 0, 0, 0.9);
            border-radius: 16px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            cursor: pointer;
            margin-left: 10px;
            font-weight: 700; /* Aplica negrito ao texto do botão */
           
        }
        .search-container button:hover {
            background-color: rgba(0, 153, 74, 0.6);
        }
        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            padding: 20px;
            max-width: 1300px;
            margin: 0 auto;
        }
        .card {
            width: 150px;
            height: 150px;
            box-sizing: border-box;
            padding: 20px;
            border: 3px solid black;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.7);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 20px rgba(255, 255, 255, 0.6);
        }
        .card a {
            text-decoration: none;
            color: inherit;
            display: block;
            width: 100%;
            height: 100%;
            font-size: 14px;
            font-weight: bold;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .resultados-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .resultado-item {
            background-color: rgba(77, 255, 184, 0.1);
            border: 1px solid rgba(77, 255, 184, 0.9);
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .resultado-item:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .resultado-item a {
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .resultado-item strong {
            color: white;
        }

       /* Media query para telas menores (celulares) */
        @media (max-width: 767px) {
            .card {
                width: calc(33.333% - 8.2px);
                height: auto;
                min-height: 100px;
            }

            .search-container {
                display: flex;
                flex-direction: column;  /* Organiza os itens em coluna */
                justify-content: center;  /* Centraliza os itens verticalmente */
                align-items: center;  /* Centraliza os itens horizontalmente */
                width: 100%;
                margin-bottom: 20px;
            }

            .search-container input[type="text"] {
                width: 100%;  /* Faz a caixa de busca ocupar quase toda a largura */
                max-width: 300px;  /* Limita a largura máxima */
            }

            .search-container button {
                width: 100%;  /* Faz o botão ter a mesma largura da caixa de busca */
                max-width: 300px;  /* Limita a largura máxima */
                margin-top: 15px;  /* Adiciona um espaço entre a caixa de busca e o botão */
            }
        }   
        
            p {
                margin: 20px; /* ajustável */
                background-color: rgba(0, 0, 0, 0.7); /* fundo preto transparente */
                color: #fff;
                padding: 5px 10px;
                border-radius: 32px ;
                box-shadow: 0 0 10px rgba(0,0,0,0.5);
                font-size: 16px;
                font-family: Arial, sans-serif;
                text-align: center;
            }

        
        
           .harpa-button {
               padding: 10px 20px;
               font-size: 16px;
               background-color: rgba(18, 9, 79, 0.9);
               color: white;
               border: 1px solid rgba(77, 255, 184, 0.8);
               border-radius: 5px;
               cursor: pointer;
               margin-left: 0px;
               margin-right: 20px; /* Adiciona um espaço à direita do botão */
        }
            .harpa-button:hover {
               background-color: #0056b3;
        }
        
       .louvor-button {
               padding: 10px 20px;
               font-size: 16px;
               background-color: rgba(18, 9, 79, 0.9);
               color: white;
               border: 1px solid rgba(77, 255, 184, 0.8);
               border-radius: 5px;
               cursor: pointer;
               margin-left: 0px;
               width: auto;
        }
            .louvor-button:hover {
               background-color: #0056b3;
        }



/* Mantém os botões lado a lado no celular */
.botoes-container {
    display: flex;
    justify-content: center;
    gap: 20px; /* Espaço entre os botões */
    margin-top: 10px; /* Espaço entre a barra de pesquisa e os botões */
    margin-bottom: 10px; /* AQUI AUMENTA O ESPAÇO ENTRE OS BOTÕES E OS CARDS */
    
}

/* PARA COMPUTADORES: Faz os botões ficarem abaixo da caixa de busca e lado a lado */
@media (min-width: 768px) {
    .botoes-container {
        justify-content: center;
        margin-top: 15px;
        margin-bottom: 50px; /* AUMENTA O ESPAÇO ENTRE OS BOTÕES E OS CARDS NO PC */
        
        
    }
}


.testamento-title {
    width: 100%; /* Ajusta a largura ao conteúdo */
    text-align: center;
    font-size: 24px;
    font-weight: italic;
    margin: 20px 0;
    color: white;
    border: 1px solid rgba(77, 255, 184, 0.9); /* Bordas verdes */
    background-color: rgba(0, 0, 0, 0.7); /* Fundo transparente */
    padding: 10px; /* Adiciona espaço interno */
    border-radius: 8px; /* Bordas arredondadas */
    display: inline-block; /* Faz o card acompanhar o título */
    max-width: 100%; /* Garante que o card não ultrapasse a tela */
    margin-left: auto; /* Centraliza o card */
    margin-right: auto; /* Centraliza o card */
}
  </style>
</head>
<body>
    
    
    
    
    <div id="installPopup" style="
  display: none;
  position: fixed;
  top: 10px;
  left: 5px;
  right: 5px;
  max-width: 500px;
  margin: 0 auto;
  background: rgba(0,0,0,0.7);
  color: white;
  padding: 15px 20px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.3);
  font-family: Arial, sans-serif;
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
">
  <span style="flex: 1;">Quer instalar o app da Bíblia no seu celular?</span>
  <button id="btnInstall" style="
    background: green;
    color: white;
    border: 2px solid white;
    padding: 8px 15px;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    white-space: nowrap;
  ">Instalar</button>
 
</div>



    
    <h1>
        <img src="logo.jpg" alt="Logo"> BÍBLIA SAGRADA
    </h1>
    <p>Desenvolvedor - Emanuel Nascimento</p>

    <!-- Formulário de pesquisa -->
    <div class="search-container">
        <form method="GET" action="">
            <input type="text" id="campo-pesquisa" name="pesquisa" placeholder="Pesquisar livro, capítulo, versículo ou palavra..." value="<?php echo htmlspecialchars($termo_pesquisa); ?>">
            <button type="submit" style="font-size: 1.0rem;">BUSCAR</button>
        </form>
        
    </div>
       <!-- NOVA DIV PARA OS BOTÕES -->
<div class="botoes-container">
    <button class="harpa-button" onclick="window.location.href='harp.html'">Harpa Cristã</button>
    <button class="louvor-button" onclick="window.location.href='louvor.html'">Hino/Louvor</button>
</div>

    <!-- Exibir resultados da pesquisa -->
<?php if (!empty($resultados)): ?>
    <div class="resultados-container">
        <h2>Resultados da Pesquisa:</h2>
        <?php foreach ($resultados as $resultado): ?>
            <div class="resultado-item">
                <a href="livro.php?id=<?php echo $resultado['book']; ?>&capitulo=<?php echo $resultado['chapter']; ?>&versiculo=<?php echo $resultado['verse']; ?>">
                    <strong><?php echo $resultado['livro_nome']; ?> <?php echo $resultado['chapter']; ?>:<?php echo $resultado['verse']; ?></strong>
                    - <?php echo htmlspecialchars($resultado['text']); ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

 <!-- Exibir livros -->
    <?php if (empty($resultados)): ?>
        <div class="card-container">
            <!-- Título do Velho Testamento -->
            <div class="testamento-title">VELHO TESTAMENTO</div>
            <?php foreach ($livros as $livro): ?>
                <?php if ($livro['id'] <= 38): ?>
                    <div class="card">
                        <a href="livro.php?id=<?php echo $livro['id']; ?>">
                            <?php echo htmlspecialchars($livro['name']); ?>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>

            <!-- Título do Novo Testamento -->
            <div class="testamento-title">NOVO TESTAMENTO</div>
            <?php foreach ($livros as $livro): ?>
                <?php if ($livro['id'] > 38): ?>
                    <div class="card">
                        <a href="livro.php?id=<?php echo $livro['id']; ?>">
                            <?php echo htmlspecialchars($livro['name']); ?>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    


<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').then(registration => {
        console.log('Service Worker registrado com sucesso:', registration);
      }).catch(error => {
        console.log('Falha ao registrar Service Worker:', error);
      });
    });
  }
</script>


<script>
  let deferredPrompt;
  const installPopup = document.getElementById('installPopup');
  const btnInstall = document.getElementById('btnInstall');
  
  // Verifica se o app está instalado
  function isAppInstalled() {
    return window.matchMedia('(display-mode: standalone)').matches || 
           window.navigator.standalone === true ||
           document.referrer.includes('android-app://');
  }

  // Esconde o popup inicialmente
  installPopup.style.display = 'none';

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Só mostra o popup se o app não estiver instalado
    if (!isAppInstalled()) {
      installPopup.style.display = 'flex';
      
      // Esconde o popup após 5 segundos
      setTimeout(() => {
        installPopup.style.display = 'none';
      }, 5000);
    }
  });

  btnInstall.addEventListener('click', () => {
    installPopup.style.display = 'none';
    
    if (deferredPrompt) {
      deferredPrompt.prompt();
      
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('Usuário aceitou a instalação');
        } else {
          console.log('Usuário rejeitou a instalação');
        }
        deferredPrompt = null;
      });
    }
  });

  // Esconde o popup se o app for instalado
  window.addEventListener('appinstalled', () => {
    console.log('App foi instalado!');
    installPopup.style.display = 'none';
  });

  // Verifica ao carregar a página se já está instalado
  window.addEventListener('load', () => {
    if (isAppInstalled()) {
      installPopup.style.display = 'none';
    }
  });
</script>

<?php include 'contador.php';?>
<?php include 'total.php';?>









<script>
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  // Impede o navegador de mostrar o prompt automaticamente
  e.preventDefault();
  deferredPrompt = e;

  // Mostra seu botão de instalação personalizado (por exemplo, popup)
  document.getElementById('botaoInstalar').style.display = 'block';

  document.getElementById('botaoInstalar').addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;

      if (outcome === 'accepted') {
        console.log('Usuário aceitou instalar');

        // ✅ Aqui registramos a instalação
        fetch('registrar_instalacao.php', {
          method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
          console.log('Instalações registradas:', data.instalacoes);
        });

        deferredPrompt = null;
      } else {
        console.log('Usuário recusou a instalação');
      }
    }
  });
});

// Apenas por segurança, escuta o evento final de instalação
window.addEventListener('appinstalled', () => {
  console.log('PWA foi instalado');
});
</script>






<script>
window.addEventListener('appinstalled', () => {
    // Quando o app é instalado, envia requisição silenciosa
    fetch('registrar_instalacao.php');
});
</script>




</body>
</html>
