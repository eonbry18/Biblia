<?php
// Inclui a conexão
include 'includes/conexao1.php';

// Caminho da pasta com os arquivos .mp3
$pasta = 'audio/';

// Caminho base para gerar a URL
$url_base = 'https://nepster.xyz/Biblia/audio/';

$arquivos = scandir($pasta);
$quantidade = 0;

foreach ($arquivos as $arquivo) {
    if (pathinfo($arquivo, PATHINFO_EXTENSION) === 'mp3') {
        $titulo = "Hino " . pathinfo($arquivo, PATHINFO_FILENAME);
        $stmt = $conn->prepare("INSERT INTO musicas (titulo, arquivo) VALUES (?, ?)");

        if ($stmt) {
            $stmt->bind_param("ss", $titulo, $arquivo);
            if ($stmt->execute()) {
                echo "✅ Inserido: $titulo<br>";
            } else {
                echo "❌ Erro ao inserir '$titulo': " . $stmt->error . "<br>";
            }
        } else {
            echo "❌ Erro ao preparar a query: " . $conn->error . "<br>";
        }
    }
}


echo "$quantidade hinos cadastrados com sucesso!";
$conn->close();
?>
