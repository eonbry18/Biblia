<?php
$arquivo = 'contador.txt';

if (!file_exists($arquivo)) {
    file_put_contents($arquivo, '0');
}

// Atualiza o contador se enviado um novo valor
if (isset($_POST['novo_valor'])) {
    $novo_valor = str_replace('.', '', $_POST['novo_valor']); // remove pontos
    if (ctype_digit($novo_valor)) {
        file_put_contents($arquivo, $novo_valor, LOCK_EX);
        $mensagem = "Contador atualizado com sucesso!";
    } else {
        $mensagem = "Valor inválido!";
    }
}

// Lê o valor atual
$valor_atual = (int)str_replace('.', '', file_get_contents($arquivo));
$valor_formatado = number_format($valor_atual, 0, '', '.');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel do Contador</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background: black;
        }
        .box {
            background: #fff;
            padding: 20px;
            max-width: 400px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        input[type="text"] {
            width: 95%;
            padding: 10px;
            margin: 10px 0;
        }
        input[type="submit"] {
            padding: 10px 15px;
            background: green;
            border: none;
            color: white;
            cursor: pointer;
        }
        .mensagem {
            color: green;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Visitas atuais: <?= $valor_formatado ?></h2>

        <?php if (isset($mensagem)) echo "<p class='mensagem'>$mensagem</p>"; ?>

        <form method="post">
            <label>Novo valor:</label>
            <input type="text" name="novo_valor" placeholder="Ex: 1000000" required>
            <input type="submit" value="Atualizar Contador">
        </form>
    </div>
</body>
</html>
