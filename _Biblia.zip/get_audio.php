<?php
header('Content-Type: application/json');
include("includes/conexao1.php"); // Faz conexão com seu banco

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Formata o ID para ter 3 dígitos (001, 002, etc.)
    $formattedId = str_pad($id, 3, '0', STR_PAD_LEFT);
    
    // Verifica primeiro no banco de dados
    $stmt = $conn->prepare("SELECT caminho FROM hinos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($caminho);
    
    if ($stmt->fetch()) {
        // Se encontrou no banco, retorna o caminho
        echo json_encode([
            "audio" => $caminho,
            "id" => $id,
            "formattedId" => $formattedId
        ]);
    } else {
        // Se não encontrou no banco, tenta o padrão 001.mp3
        $defaultPath = "audios/" . $formattedId . ".mp3";
        
        // Verifica se o arquivo existe fisicamente
        if (file_exists($defaultPath)) {
            echo json_encode([
                "audio" => $defaultPath,
                "id" => $id,
                "formattedId" => $formattedId
            ]);
        } else {
            echo json_encode([
                "error" => "Áudio não encontrado",
                "id" => $id,
                "formattedId" => $formattedId
            ]);
        }
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "ID não informado"]);
}

$conn->close();
?>