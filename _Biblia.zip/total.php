<?php
$arquivo = 'instala.txt';
$contador = file_exists($arquivo) ? (int)file_get_contents($arquivo) : 0;
echo "Total de instalações: $contador";
?>


