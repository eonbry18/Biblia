<?php
// Dados de conexão
$host = 'localhost'; // Host do banco de dados
$dbname = 'u544804289_bibli';  // Nome do banco de dados
$user = 'u544804289_bibli'; // Usuário do banco de dados
$pass = '#8b2F>0B3Ht';   // Senha do banco de dados

// Conectar ao banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar: " . $e->getMessage());
}
?>