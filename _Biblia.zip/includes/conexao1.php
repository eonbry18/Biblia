<?php
// Conexão com o banco
$host = "localhost";
$usuario = "u544804289_hinos";
$senha = "uxla:+U4w";
$banco = "u544804289_hinos";

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Caminho da pasta com os arquivos .mp3
$pasta = 'audio/';
$arquivos = scandir($pasta);

$inseridos = 0;

foreach ($arquivos as $arquivo) {
    if (pathinfo($arquivo, PATHINFO_EXTENSION) === 'mp3') {
        $titulo = "Hino " . pathinfo($arquivo, PATHINFO_FILENAME);

        // Verifica se já existe no banco para evitar duplicatas
        $check = $conn->prepare("SELECT id FROM musicas WHERE arquivo = ?");
        $check->bind_param("s", $arquivo);
        $check->execute();
        $check->store_result();

        if ($check->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO musicas (titulo, arquivo) VALUES (?, ?)");
            if ($stmt) {
                $stmt->bind_param("ss", $titulo, $arquivo);
                if ($stmt->execute()) {
                    echo "✅ Inserido: $titulo<br>";
                    $inseridos++;
                } else {
                    echo "❌ Erro ao inserir $titulo: " . $stmt->error . "<br>";
                }
            } else {
                echo "❌ Erro no prepare: " . $conn->error . "<br>";
            }
        } else {
            echo "ℹ️ Já existe: $titulo<br>";
        }
    }
}

echo "<hr><strong>Total inserido: $inseridos hinos.</strong>";
$conn->close();
?>
