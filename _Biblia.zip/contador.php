<?php
$arquivo_contador = "contador.txt";

// Cria o arquivo com valor 0 se não existir
if (!file_exists($arquivo_contador)) {
    file_put_contents($arquivo_contador, "0", LOCK_EX);
}

// Lê o conteúdo do arquivo e remove qualquer ponto de separador
$conteudo = file_get_contents($arquivo_contador);
$contador = (int)str_replace('.', '', $conteudo); // remove pontos e converte para inteiro

// Incrementa o contador
$contador++;

// Salva de volta SEM separador de milhar
file_put_contents($arquivo_contador, $contador, LOCK_EX);

// Formata com separador de milhar só para mostrar
$contador_formatado = number_format($contador, 0, '', '.');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Contador de Visitas</title>
    <style>
    body {
        margin: 0;
        padding-top: 50px;
    }
    .contador-container {
        background-color: rgba(0, 0, 0, 0.7);
        color: #fff;
        padding: 1px 10px;
        border-radius: 0 0 10px 0;
        position: fixed;
        top: 0;
        left: 0;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);
        text-align: left;
        font-size: 16px;
        font-family: Arial, sans-serif;
        z-index: 9999;
    }
    </style>
</head>
<body>

<div class="contador-container">
    <?php echo "Visitas ao Site: " . $contador_formatado; ?>
</div>

</body>
</html>
