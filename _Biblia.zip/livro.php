<?php
// Habilitar a exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclui o arquivo de conexão
include 'includes/conexao.php';

// Verifica se o ID do livro foi passado na URL
if (!isset($_GET['id'])) {
    die("Erro: ID do livro não especificado!");
}

// Pega o ID do livro da URL
$livro_id = $_GET['id'];

// Verifica se o parâmetro "versiculo" foi passado na URL
if (isset($_GET['versiculo'])) {
    $versiculo = intval($_GET['versiculo']);

    // Consulta para encontrar o capítulo correspondente ao versículo
    $sql_capitulo = "SELECT chapter FROM verses WHERE book = :livro_id AND verse = :versiculo LIMIT 1";
    $stmt_capitulo = $pdo->prepare($sql_capitulo);
    $stmt_capitulo->execute(['livro_id' => $livro_id, 'versiculo' => $versiculo]);
    $capitulo_info = $stmt_capitulo->fetch(PDO::FETCH_ASSOC);

    if ($capitulo_info) {
        // Redireciona para a página do capítulo com o versículo específico
        header("Location: capitulo.php?book=$livro_id&capitulo=" . $capitulo_info['chapter'] . "&versiculo=$versiculo");
        exit();
    } else {
        die("Erro: Versículo não encontrado!");
    }
}

// Consulta para buscar os capítulos do livro (agrupando os versículos por capítulo)
$sql = "SELECT DISTINCT chapter FROM verses WHERE book = :livro_id ORDER BY chapter";
$stmt = $pdo->prepare($sql);
$stmt->execute(['livro_id' => $livro_id]);
$capitulos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consulta para pegar o nome do livro
$sql_livro = "SELECT name FROM books WHERE id = :livro_id";
$stmt_livro = $pdo->prepare($sql_livro);
$stmt_livro->execute(['livro_id' => $livro_id]);
$livro = $stmt_livro->fetch(PDO::FETCH_ASSOC);

// Verifica se o livro foi encontrado
if (!$livro) {
    die("Erro: Livro não encontrado!");
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $livro['name']; ?> - Capítulos</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: black; /* Fundo preto */
            color: white; /* Texto branco para contraste */
            margin: 0;
            padding: 20px;
        }
        h1 {
            display: flex; /* Usa flexbox para alinhar a imagem e o texto */
            align-items: center; /* Centraliza verticalmente a imagem e o texto */
            justify-content: center; /* Centraliza horizontalmente o conteúdo */
            gap: 10px; /* Adiciona um espaço entre a imagem e o texto */
            margin-bottom: 20px;
            color: white; /* Texto do título em branco */
        }
        h1 img {
            width: 50px; /* Largura da imagem */
            height: 40px; /* Altura da imagem */
            border-radius: 50%; /* Bordas arredondadas */
        }
        .cards-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
        }
        .card {
            background-color: rgba(0, 0, 0, 0.3); /* Fundo preto com transparência */
            border: 2px solid rgba(255, 255, 255, 0.9); /* Borda branca com transparência */
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.9);
            width: 150px;
            padding: 15px;
            text-align: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-5px); /* Efeito de levantar o card */
            box-shadow: 0 10px 8px rgba(255, 255, 255, 0.6); /* Sombra branca com transparência ao passar o mouse */
        }
        .card a {
            text-decoration: none;
            color: yellow; /* Texto dos links em branco */
            font-size: 18px;
            font-weight: bold;
            width: 100%; /* Garante que o link ocupe toda a área do card */
            height: 100%; /* Garante que o link ocupe toda a área do card */
            display: block; /* Faz o link ocupar todo o espaço do card */
        }
        
        /* Media query para telas menores (celulares) */
        @media (max-width: 767px) {
            .card {
                width: calc(33.333% - 8px); /* 2 cards por linha em celulares, com gap de 15px */
                height: auto; /* Altura automática para se adaptar ao conteúdo */
                min-height: auto; /* Altura mínima para garantir consistência */
            }
            .cards-container {
                gap: 15px; /* Espaçamento entre os cards */
            }
        }
    </style>
</head>
<body>
    <h1>
        <img src="logo.jpg" alt="Logo"> <!-- Imagem adicionada ao lado do título -->
        <?php echo $livro['name']; ?> <!-- Nome do livro -->
    </h1>
    <div class="cards-container">
        <?php foreach ($capitulos as $capitulo): ?>
            <div class="card">
                <a href="capitulo.php?book=<?php echo $livro_id; ?>&capitulo=<?php echo $capitulo['chapter']; ?>">
                    Capítulo <?php echo $capitulo['chapter']; ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>