<?php
$arquivo_contador = 'instala.txt';
$arquivo_ips = 'ip_instalacoes.txt';

// Cria os arquivos se não existirem
if (!file_exists($arquivo_contador)) {
    file_put_contents($arquivo_contador, "0", LOCK_EX);
}
if (!file_exists($arquivo_ips)) {
    file_put_contents($arquivo_ips, "", LOCK_EX);
}

// Função para pegar IP real do usuário
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    return $_SERVER['REMOTE_ADDR'];
}

$ip = getUserIP();

// Lê os IPs já registrados
$ips_registrados = file($arquivo_ips, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

// Se o IP ainda não foi contado
if (!in_array($ip, $ips_registrados)) {
    // Incrementa o contador com segurança
    $contador = (int)file_get_contents($arquivo_contador);
    $contador++;
    file_put_contents($arquivo_contador, $contador, LOCK_EX);

    // Registra o IP
    file_put_contents($arquivo_ips, $ip . PHP_EOL, FILE_APPEND | LOCK_EX);
}

// Retorna status 200
http_response_code(200);
?>
