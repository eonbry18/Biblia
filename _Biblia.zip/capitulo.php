<?php
include 'includes/conexao.php';
if (!isset($_GET['book']) || !isset($_GET['capitulo'])) {
    die("Erro: Livro ou capítulo não especificado.");
}

$livro_id = $_GET['book'];
$capitulo_numero = $_GET['capitulo'];

$stmt_livro = $pdo->prepare("SELECT name FROM books WHERE id = :livro_id");
$stmt_livro->execute(['livro_id' => $livro_id]);
$livro = $stmt_livro->fetch(PDO::FETCH_ASSOC);
if (!$livro) die("Erro: Livro não encontrado.");

$stmt = $pdo->prepare("SELECT DISTINCT chapter FROM verses WHERE book = :livro_id ORDER BY chapter");
$stmt->execute(['livro_id' => $livro_id]);
$capitulos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt_versiculos = $pdo->prepare("SELECT verse, text FROM verses WHERE book = :livro_id AND chapter = :capitulo ORDER BY verse");
$stmt_versiculos->execute(['livro_id' => $livro_id, 'capitulo' => $capitulo_numero]);
$versiculos = $stmt_versiculos->fetchAll(PDO::FETCH_ASSOC);

$lista_capitulos = array_map(fn($item) => $item['chapter'], $capitulos);
$indice_atual = array_search($capitulo_numero, $lista_capitulos);
$capitulo_anterior = $indice_atual > 0 ? $lista_capitulos[$indice_atual - 1] : null;
$capitulo_proximo = $indice_atual < count($lista_capitulos) - 1 ? $lista_capitulos[$indice_atual + 1] : null;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title><?php echo $livro['name']; ?> - Capítulo <?php echo $capitulo_numero; ?></title>
    <link rel="icon" href="logo.jpg" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background: black;
            color: white;
            font-family: Arial, sans-serif;
            padding: 20px;
            margin: 0;
        }
        h1 {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        h1 img {
            width: 50px;
            height: 40px;
            border-radius: 50%;
        }
        .titulo-capitulos {
            text-align: center;
            color: yellow;
            margin: 30px 0 10px;
            font-size: 24px;
        }
        .scroll-capitulos {
            display: flex;
            overflow-x: auto;
            gap: 10px;
            padding-bottom: 10px;
            scroll-behavior: smooth;
        }
        .scroll-capitulos::-webkit-scrollbar {
            height: 6px;
        }
        .scroll-capitulos::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }
        .card-capitulo {
            padding: 10px 15px;
            border-radius: 5px;
            background: rgba(77, 255, 184, 0.3);
            border: 1px solid rgba(77, 255, 184, 0.8);
            text-align: center;
            min-width: 40px;
            transition: transform 0.2s;
        }
        .card-capitulo a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        .card-capitulo:hover {
            transform: scale(1.05);
        }
        .card-capitulo.ativo {
            background: red;
            border-color: white;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(77, 255, 184, 0.6);
            border-radius: 8px;
        }
        li {
            margin-bottom: 10px;
            padding: 10px;
            background-color: rgba(255,255,255,0.05);
            border-radius: 4px;
        }
        li strong {
            color: yellow;
        }
        
        .scroll-capitulos {
    display: flex;
    overflow-x: auto;
    gap: 10px;
    padding-bottom: 10px;
    scroll-behavior: smooth;
    scroll-snap-type: x proximity;
}

.scroll-capitulos > .card-capitulo {
    scroll-snap-align: center;
}
    </style>
</head>
<body>
    <h1>
        <img src="logo.jpg" alt="Logo">
        <?php echo $livro['name']; ?> - Capítulo <?php echo $capitulo_numero; ?>
    </h1>

    <h2 class="titulo-capitulos">CAPÍTULOS</h2>
    <div class="scroll-capitulos" id="barraCapitulosTopo">
        <?php foreach ($capitulos as $capitulo): ?>
            <div class="card-capitulo <?php echo $capitulo['chapter'] == $capitulo_numero ? 'ativo' : ''; ?>" id="capitulo-<?php echo $capitulo['chapter']; ?>">
                <a href="capitulo.php?book=<?php echo $livro_id; ?>&capitulo=<?php echo $capitulo['chapter']; ?>">
                    <?php echo $capitulo['chapter']; ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="container">
        <ul>
            <?php foreach ($versiculos as $versiculo): ?>
                <li>
                    <strong><?php echo $versiculo['verse']; ?>:</strong> <?php echo trim($versiculo['text']); ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    
     <h1>
        <img src="logo.jpg" alt="Logo">
        <?php echo $livro['name']; ?> - Capítulo <?php echo $capitulo_numero; ?>
    </h1>
     <h2 class="titulo-capitulos">CAPÍTULOS</h2>

    <div class="scroll-capitulos" id="barraCapitulosRodape">
        <?php foreach ($capitulos as $capitulo): ?>
            <div class="card-capitulo <?php echo $capitulo['chapter'] == $capitulo_numero ? 'ativo' : ''; ?>" id="capitulo-<?php echo $capitulo['chapter']; ?>">
                <a href="capitulo.php?book=<?php echo $livro_id; ?>&capitulo=<?php echo $capitulo['chapter']; ?>">
                    <?php echo $capitulo['chapter']; ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

  <script>
    // Função para rolar as barras até o capítulo selecionado
   function rolarBarraCapitulo(capituloNumero) {
    // Rolar a barra superior
    const capituloSelecionadoTopo = document.querySelector('#barraCapitulosTopo #capitulo-' + capituloNumero);
    if (capituloSelecionadoTopo) {
        capituloSelecionadoTopo.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }

    // Rolar a barra inferior
    const capituloSelecionadoRodape = document.querySelector('#barraCapitulosRodape #capitulo-' + capituloNumero);
    const barraRodape = document.getElementById('barraCapitulosRodape');
    if (capituloSelecionadoRodape && barraRodape) {
        // Calcula a posição para rolar
        const scrollLeft = capituloSelecionadoRodape.offsetLeft - 
                          (barraRodape.offsetWidth / 2) + 
                          (capituloSelecionadoRodape.offsetWidth / 2);
        
        barraRodape.scrollTo({
            left: scrollLeft,
            behavior: 'smooth'
        });
    }
}

window.addEventListener('load', () => {
    // Rolar para o capítulo selecionado ao carregar a página
    rolarBarraCapitulo('<?php echo $capitulo_numero; ?>');
});
    // Função de gestos para navegação entre capítulos
    let touchStartX = 0;
    let touchStartY = 0;
    let touchEndX = 0;
    let isTouchOnCapitulos = false;

    function handleGesture() {
        if (isTouchOnCapitulos) {
            isTouchOnCapitulos = false;
            return;
        }

        let diffX = touchEndX - touchStartX;
        let diffY = Math.abs(touchStartY - event.changedTouches[0].screenY);

        // Só considera swipe se for quase horizontal (evita rolagem vertical)
        if (Math.abs(diffX) > 50 && diffY < 30) {
            if (diffX < 0) {
                <?php if ($capitulo_proximo !== null): ?>
                    window.location.href = "capitulo.php?book=<?php echo $livro_id; ?>&capitulo=<?php echo $capitulo_proximo; ?>";
                <?php endif; ?>
            } else {
                <?php if ($capitulo_anterior !== null): ?>
                    window.location.href = "capitulo.php?book=<?php echo $livro_id; ?>&capitulo=<?php echo $capitulo_anterior; ?>";
                <?php endif; ?>
            }
        }
    }

    document.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
        touchStartY = e.changedTouches[0].screenY;
        isTouchOnCapitulos = e.target.closest('.scroll-capitulos') !== null;
    }, false);

    document.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].screenX;
        handleGesture(e);
    }, false);
</script>



</body>
</html>
